from django.shortcuts import render
from django.http import HttpResponse
from .models import product
from django.views.generic import ListView
# Create your views here.
def home(request):
    prod=product.objects.all()
    return render(request,'index.html',{'product':prod});


class productListView(ListView):
    model=product
    context_obj_name=product
    template_name='list.html'
