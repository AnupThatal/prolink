from django.apps import AppConfig


class ProlinknepalConfig(AppConfig):
    name = 'prolinknepal'
